package com.badlogic.gdx.tests.bullet;

import com.badlogic.gdx.Game;
import com.kotcrab.vis.ui.VisCHLoader;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

public class 启动器 extends Game {

    Skin skin;
    
    @Override
    public void create() {
        skin = VisCHLoader.load(); 
        setScreen(new VehicleTest());
    }
}
