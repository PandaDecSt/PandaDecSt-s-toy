package com.badlogic.gdx.tests.bullet.ui;

import com.kotcrab.vis.ui.widget.Menu;

/**
 * @author Marcus Brummer
 * @version 22-11-2015
 */
public class WindowMenu extends Menu {

    public WindowMenu() {
        super("窗口");
    }

}
