package com.badlogic.gdx.tests.bullet;

public class BulletConstructorFactory {
    
    public static BulletConstructor constructCapsule(float r, float h) {
        return new BulletConstructor(createCapsuleModel(r, h), 1f, new btCapsuleShape(r,h));
    }
    
    public static  BulletConstructor constructBox(float w, float h, float d) {
        return new BulletConstructor(createBoxModel(w, h, d), 1f, new btBoxShape(new Vector3(w,h,d)));
        }
        
    public static BulletConstructor constructBox(float r, float h) {
        return constructBox(r, h, r);
    }
    
    public static BulletConstructor constructBox(float w, float h, float d, float s) {
        return constructBox(w*s, h*s, d*s);
    }
    
}
