package com.badlogic.gdx.tests.bullet;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;

public class ModelFactory {
    
    public ModelBuilder modelBuilder = new ModelBuilder();
    
    public static Model createCapsuleModel (float r, float h) {
        final Model result = modelBuilder.createCapsule(r, h + r * 2f, 16,
            new Material(ColorAttribute.createDiffuse(Color.WHITE), ColorAttribute.createSpecular(Color.WHITE)), Usage.Position
                | Usage.Normal);
        disposables.add(result);
        return result;
    }
    
    public static Model createBoxModel (float w, float h, float d) {
        final Model result = modelBuilder.createBox(w, h, d, new Material(ColorAttribute.createDiffuse(Color.WHITE), ColorAttribute.createSpecular(Color.WHITE)), Usage.Position|Usage.Normal);
        disposables.add(result);
        return result;
	}
    
}
