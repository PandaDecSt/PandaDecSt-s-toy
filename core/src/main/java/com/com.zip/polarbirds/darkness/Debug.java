package com.polarbirds.darkness;

/**
 * Created by Kristian Rekstad on 05.03.2015.
 */
public class Debug {
    public static boolean DEBUG = true;
}
