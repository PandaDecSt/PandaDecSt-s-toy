package com.polarbirds.darkness.util;

/**
 * Created by Kristian Rekstad on 23.04.2015.
 */
public interface Callback {
    public void onCallback(String event);
}
