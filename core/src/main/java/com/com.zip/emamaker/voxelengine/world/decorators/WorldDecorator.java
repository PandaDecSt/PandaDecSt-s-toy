package  com.emamaker.voxelengine.world.decorators;

import  com.emamaker.voxelengine.world.Chunk;

public abstract class WorldDecorator {
    
    public abstract void decorate(Chunk c);
    
}
